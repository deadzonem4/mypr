<?php
/*
Plugin Name: Master Magazine
Plugin URI: http://themnific.com
Description: Enhance your blog site with magazine features.
Author: Dannci
Version: 1.0
Author URI: http://themnific.com
License: GPL2
*/
/*  Copyright 2016  Themnific (Dannci)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License, version 2, as 
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
if ( !class_exists( 'MasterMag' ) ) :

final class MasterMag {};

////////////
// variables
$master_mag_main_file = dirname(__FILE__).'/master-magazine.php';
$master_mag_directory = plugin_dir_url($master_mag_main_file);
$master_mag_path = dirname(__FILE__);

////////////
// plugin version
function mastermag_version(){
$plugin_data = get_plugin_data( __FILE__ );
    $plugin_version = $plugin_data['Version'];
    return $plugin_version;
}

////////////
// plugin specific functionality
require_once 'functions/mm-shortcodes.php';			// Shortcode queries 
require_once ('functions/ptype-info.php'); 			// info post type




////////////
// text domain
load_plugin_textdomain('MasterMag', false, basename( dirname( __FILE__ ) ) . '/languages' );


//////////////
// LAYOUT CREATOR

//definitions
if(!defined('MLLC_VERSION')) define( 'MLLC_VERSION', '1.0.0' );
if(!defined('MLLC_PATH')) define( 'MLLC_PATH', plugin_dir_path(__FILE__) );
if(!defined('MLLC_DIR')) define( 'MLLC_DIR', plugin_dir_path(__FILE__) );

//required functions & classes
require_once (MLLC_PATH  . 'layoutcreator/mllc_config.php');
require_once (MLLC_PATH  . 'layoutcreator/mllc_blocks.php');
require_once (MLLC_PATH  . 'layoutcreator/class-ml-page-builder.php');
require_once (MLLC_PATH  . 'layoutcreator/class-ml-block.php');
require_once (MLLC_PATH  . 'layoutcreator/mllc_functions.php');


//fire up layout creator
$MLLC_config = ml_page_builder_config();
$ml_page_builder = new ML_Page_Builder($MLLC_config);
if(!is_network_admin()) $ml_page_builder->init();


//author box - additional links
function mastermag_contactmethods( $contactmethods ) {
	
	$contactmethods['twitter'] = 'Twitter';
	$contactmethods['facebook'] = 'Facebook';
	$contactmethods['google'] = 'Google+';
	$contactmethods['linkedin'] = 'Linked in';
	$contactmethods['pinterest'] = 'Pinterest';
	$contactmethods['instagram'] = 'Instagram';
	$contactmethods['google'] = 'Google+';
	$contactmethods['link'] = 'Any Link';
	
	return $contactmethods;
}
add_filter('user_contactmethods','mastermag_contactmethods',10,1);

endif; // class_exists check
?>