<?php

// BLOCKS - menu shortcode
function tmnf_menu_shortcode($atts, $content = null) {
    extract(shortcode_atts(array( 'name' => null, ), $atts));
    return wp_nav_menu( array( 'menu' => $name, 'echo' => false ) );
}
add_shortcode('menu', 'tmnf_menu_shortcode');

//////////////
/* MENU  */
//////////////

function tmnf_magmenu($atts, $content = null) {
	extract(shortcode_atts(array(
		"query" => '',
		"category" => '',
	), $atts));
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if(!empty($category)){
		$query .= 'showposts=5&category_name='.esc_attr($category);
	}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
	<ul class="loop sf-mega">
	<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
		<li class="menu-post">
        	<div class="inner tranz">
                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('mm_thumb',array('class' => 'tranz grayscale grayscale-fade')); ?></a>
                <p class="meta cat tranz ribbon"><?php the_category(' &bull; ') ?></p>
            </div>
            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
        </li>
	<?php endwhile; ?>
	</ul>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
	wp_reset_query();
}
add_shortcode("blog-menu", "tmnf_magmenu");


//2nd blog menu
function tmnf_magmenu2($atts, $content = null) {
	extract(shortcode_atts(array(
		"pagination" => 'true',
		"query" => '',
		"category" => '',
	), $atts));
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if(!empty($category)){
		$query .= 'showposts=5&category_name='.esc_attr($category);
	}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
	<ul class="loop sf-mega">
	<?php while ($wp_query->have_posts()) : $wp_query->the_post(); ?>
		<li class="menu-post">
        	<div class="inner tranz">
                <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('mm_thumb',array('class' => 'tranz grayscale grayscale-fade')); ?></a>
                <p class="meta cat tranz ribbon"><?php the_category(' &bull; ') ?></p>
            </div>
            <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
        </li>
	<?php endwhile; ?>
	</ul>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
	wp_reset_query();
}
add_shortcode("blog-menu-2", "tmnf_magmenu2");


/*-----------------------------------------------------------------------------------*/
/* [mm-info]
/*-----------------------------------------------------------------------------------*/

function mp_services($atts, $content = null) {
	extract(shortcode_atts(array(
		"query" => '',
        "category" => '',
		"posts" => '',
		"columns" => '3',
		"layout" => '' /* 0 / modern / classic */,
		"type" => '' /* 0 / boxed */,
	), $atts));
	global $wp_query,$paged,$post;
	$temp = $wp_query;
	$wp_query= null;
	$wp_query = new WP_Query();
	if($category === 'flase'){
		$query .= 'post_type=mp_info_post&showposts='.$posts;
	}
	else {$query .= 'post_type=mp_info_post&mp_specifics='.$category.'&showposts='.$posts;}
	if(!empty($query)){
		$query .= $query;
	}
	$wp_query->query($query);
	ob_start();
	?>
    <div class="mm-wrap">
	<ul class="mmbox col<?php echo $columns ?> <?php echo $layout ?> <?php echo $type ?>">
	<?php while ($wp_query->have_posts()) : $wp_query->the_post();?>
            
			<?php 
                $info_link = get_post_meta(get_the_ID(), 'themnific_mm_info_link', true);
            ?>
                  
                <li class="mm-info tranz">
                
                	<div class="mm-inner tranz item">
                        
                        <?php if ($info_link) { ?>
                        
                        	<a href="<?php echo esc_url($info_link); ?>"><?php the_post_thumbnail('mm_thumb',array('class' => 'tranz grayscale grayscale-fade'));?></a>
                    
                    		<h2><a class="link link--forsure" href="<?php echo esc_url($info_link); ?>"><?php the_title(  ); ?></a></h2>
                            
                        <?php } else { ?>
                        
                        	<?php the_post_thumbnail('mm_thumb',array('class' => 'tranz grayscale grayscale-fade')); ?>
                        
							<h2><?php the_title(  ); ?></h2>
                            
                        <?php } ?>       
                               
                        <?php the_content(); ?>
                    
                    </div>
                    
                </li>
            
	<?php endwhile; ?>
    </ul>
    </div> 
    <div class="clearfix"></div>
    <?php wp_reset_query(); ?>
	<?php $wp_query = null; $wp_query = $temp;
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode("mm-info", "mp_services");



?>