<?php
/**
 * Master Layout Config
 *
 */
function ml_page_builder_config() {

	$config = array(); //initialise array
	
	/* Page Config */
	$config['menu_title'] = esc_html__('Layout Creator','vaha');
	$config['page_title'] = esc_html__('Layout Creator','vaha');
	$config['page_slug'] = esc_html__('ml-laoyut-creator','vaha');
	
	/* This holds the contextual help text - the more info, the better.
	 * HTML is of course allowed in all of its glory! */
	$config['contextual_help'] = 
		'<p>' . esc_html__('The layout creator allows you to create custom page templates which you can later use for your pages.','vaha') . '<p>' .
		'<p>' . esc_html__('To use the layout creator, start by adding a new template. You can drag and drop the blocks on the left into the building area on the right of the screen. Each block has its own unique configuration which you can manually configure to suit your needs','vaha') . '<p>' .
	
	/* Debugging */
	$config['debug'] = false;
	
	return $config;
	
}